---
name: Leaflet.Polyline.SnakeAnim
category: overlay-animations
repo: https://github.com/IvanSanchez/Leaflet.Polyline.SnakeAnim
author: Iván Sánchez Ortega
author-url: https://github.com/IvanSanchez
demo: 
compatible-v0:
compatible-v1: true
---

Animates (poly)lines into existence, as if they were being slowly drawn from start to end.
