---
name: Leaflet.Marker.SlideTo
category: overlay-animations
repo: https://gitlab.com/IvanSanchez/Leaflet.Marker.SlideTo
author: Iván Sánchez Ortega
author-url: https://gitlab.com/u/IvanSanchez
demo: http://ivansanchez.gitlab.io/Leaflet.Marker.SlideTo/demo.html
compatible-v0:
compatible-v1: true
---

Smoothly move (slide) markers to a new location.
