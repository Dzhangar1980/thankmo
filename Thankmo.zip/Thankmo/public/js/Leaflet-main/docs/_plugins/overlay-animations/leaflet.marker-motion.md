---
name: Leaflet.MarkerMotion
category: overlay-animations
repo: https://github.com/AlejandroRM-DEV/Leaflet.MarkerMotion
author: AlejandroRM-DEV
author-url: https://github.com/AlejandroRM-DEV
demo: https://leaflet-marker-motion.vercel.app/
compatible-v0:
compatible-v1: true
---

Leaflet.MarkerMotion is a powerful open-source plugin for Leaflet that enables smooth marker animation along predefined paths. Perfect for visualizing routes or creating engaging map-based animations.
