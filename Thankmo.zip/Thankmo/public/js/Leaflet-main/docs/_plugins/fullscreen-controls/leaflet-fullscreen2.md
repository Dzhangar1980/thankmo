---
name: Leaflet.fullscreen
category: fullscreen-controls
repo: https://github.com/Leaflet/Leaflet.fullscreen
author: jfirebaugh
author-url: https://github.com/jfirebaugh
demo: https://leaflet.github.io/Leaflet.fullscreen/
compatible-v0:
compatible-v1: true
---

A fullscreen button control using the Fullscreen API.
