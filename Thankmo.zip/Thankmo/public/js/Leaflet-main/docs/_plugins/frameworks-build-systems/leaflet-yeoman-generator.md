---
name: Leaflet Yeoman Generator
category: frameworks-build-systems
repo: https://github.com/moklick/generator-leaflet
author: Moritz Klack
author-url: https://github.com/moklick
demo: https://leaf-gen.moritzklack.com/
compatible-v0:
compatible-v1: true
---

Yeoman generator that scaffolds out a basic Leaflet map application.
