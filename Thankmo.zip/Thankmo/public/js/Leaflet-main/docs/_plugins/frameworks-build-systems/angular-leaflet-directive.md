---
name: Angular Leaflet directive
category: frameworks-build-systems
repo: https://github.com/tombatossals/angular-leaflet-directive
author: David Rubert
author-url: https://github.com/tombatossals
demo: https://tombatossals.github.io/angular-leaflet-directive/#!/
compatible-v0:
compatible-v1: true
---

Integrate Leaflet in applications made with the <a href="https://angularjs.org/">AngularJS</a> web framework.
