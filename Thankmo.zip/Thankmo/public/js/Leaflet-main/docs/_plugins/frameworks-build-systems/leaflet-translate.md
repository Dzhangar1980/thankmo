---
name: Leaflet.translate
category: frameworks-build-systems
repo: https://github.com/nfreear/leaflet.plugins
author: Nick Freear
author-url: https://nick.freear.org.uk/
demo: https://nfreear.github.io/leaflet.plugins/
compatible-v0:
compatible-v1: true
---

A localization/ translation plugin for Leaflet core and plugins.

The plugin contains both translations/ language pack files, and code to load them.
