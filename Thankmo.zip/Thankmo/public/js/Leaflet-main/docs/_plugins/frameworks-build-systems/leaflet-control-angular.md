---
name: Leaflet Control Angular
category: frameworks-build-systems
repo: https://github.com/grantHarris/leaflet-control-angular
author: Grant Harris
author-url: https://github.com/grantHarris
demo: 
compatible-v0:
compatible-v1: true
---

Insert and use Angularized HTML code in your Leaflet map as a Leaflet control.
