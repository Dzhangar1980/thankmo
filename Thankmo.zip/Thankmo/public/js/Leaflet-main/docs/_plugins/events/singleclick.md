---
name: singleclick
category: events
repo: https://github.com/MazeMap/Leaflet.singleclick
author: Iván Sánchez Ortega
author-url: https://github.com/IvanSanchez
demo: https://mazemap.github.io/Leaflet.singleclick/
compatible-v0: false
compatible-v1: true
---

Extend <code>L.Evented</code> to fire a <code>singleclick</code> event. Compatible with Leaflet 1.0.0-beta1 and greater only.
