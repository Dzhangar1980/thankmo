---
name: L.Spotlight
category: events
repo: https://github.com/iboates/leaflet-spotlight
author: Isaac Boates
author-url: https://github.com/iboates
demo: 
compatible-v0:
compatible-v1: true
---

Dynamically highlight features near the mouse cursor with a customizable shape
