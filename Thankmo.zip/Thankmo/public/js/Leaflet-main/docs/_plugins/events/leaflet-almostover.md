---
name: Leaflet.AlmostOver
category: events
repo: https://github.com/makinacorpus/Leaflet.AlmostOver
author: Mathieu Leplatre
author-url: https://github.com/makinacorpus/
demo: https://makinacorpus.github.io/Leaflet.AlmostOver/
compatible-v0:
compatible-v1: true
---

Trigger mouse events when cursor is "almost" over a layer.
