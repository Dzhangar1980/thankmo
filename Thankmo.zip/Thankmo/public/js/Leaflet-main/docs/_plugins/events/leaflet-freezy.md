---
name: Leaflet.Freezy
category: events
repo: https://gitlab.com/mrubli/leaflet-freezy
author: Martin Rubli
author-url: https://gitlab.com/mrubli/
demo: https://mrubli.gitlab.io/leaflet-freezy/
compatible-v0:
compatible-v1: true
---

Avoid unwanted scroll capture using hover-to-activate or click-to-activate.
