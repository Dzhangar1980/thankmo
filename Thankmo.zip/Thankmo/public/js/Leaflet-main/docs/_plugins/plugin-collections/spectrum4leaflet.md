---
name: Spectrum4Leaflet
category: plugin-collections
repo: https://github.com/Estimap/Spectrum4Leaflet
author: SVoyt
author-url: https://github.com/SVoyt
demo: 
compatible-v0:
compatible-v1: true
---

Tools for using Spectrum Spatial Server services with leaflet. This plugin supports: map service, tile service, feature service. It has layers, legend and feature controls.
