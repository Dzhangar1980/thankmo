---
name: Leaflet-pip
category: geoprocessing
repo: https://github.com/mapbox/leaflet-pip
author: Tom MacWright
author-url: https://github.com/tmcw
demo: https://mapbox.github.io/leaflet-pip/
compatible-v0:
compatible-v1: true
---

Simple point in polygon calculation using <a href="https://github.com/substack/point-in-polygon">point-in-polygon</a>.
