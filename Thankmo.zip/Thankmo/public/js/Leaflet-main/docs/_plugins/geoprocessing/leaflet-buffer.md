---
name: Leaflet.buffer
category: geoprocessing
repo: https://github.com/skeate/Leaflet.buffer
author: Jonathan Skeate
author-url: https://github.com/skeate
demo: 
compatible-v0:
compatible-v1: true
---

Enables buffering of shapes drawn with Leaflet.draw.
