---
name: Leaflet.GeometryUtil
category: geoprocessing
repo: https://github.com/makinacorpus/Leaflet.GeometryUtil
author: Benjamin Becquet
author-url: https://github.com/bbecquet
demo: 
compatible-v0:
compatible-v1: true
---

A collection of utilities for Leaflet geometries (linear referencing, etc.)
