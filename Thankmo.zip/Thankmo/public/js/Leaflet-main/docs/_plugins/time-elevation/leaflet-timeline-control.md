---
name: Leaflet Timeline Control
category: time-elevation
repo: https://github.com/zimmicz/Leaflet-Timeline-Control
author: Michal Zimmermann
author-url: https://github.com/zimmicz
demo: https://codesandbox.io/s/leaflet-timeline-control-ibyby
compatible-v0:
compatible-v1: true
---

Unopinionated timeline control that helps you display time series data.
