---
name: Leaflet Hex Time Slider
category: time-elevation
repo: https://github.com/albertkun/leaflet_hex_timeslider/
author: Albert Kochaphum
author-url: https://github.com/albertkun
demo: https://albertkun.github.io/leaflet_hex_timeslider/
compatible-v0:
compatible-v1: true
---

Minimalistic time slider using leaflet + d3.js and nouislider for displaying time series data using a geoJSON file.
