---
name: Leaflet.hotline
category: time-elevation
repo: https://github.com/iosphere/Leaflet.hotline
author: iosphere
author-url: https://github.com/iosphere
demo: https://iosphere.github.io/Leaflet.hotline/demo/
compatible-v0:
compatible-v1: true
---

A Leaflet plugin for drawing gradients along polylines.
