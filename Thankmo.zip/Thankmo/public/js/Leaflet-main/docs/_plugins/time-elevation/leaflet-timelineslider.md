---
name: Leaflet.timelineSlider
category: time-elevation
repo: https://github.com/svitkin/leaflet-timeline-slider/
author: Sol Vitkin
author-url: https://github.com/svitkin
demo: https://svitkin.github.io/leaflet-timeline-slider/
compatible-v0:
compatible-v1: true
---

Leaflet plugin that creates a customizable timeline slider with user designed functionality.
