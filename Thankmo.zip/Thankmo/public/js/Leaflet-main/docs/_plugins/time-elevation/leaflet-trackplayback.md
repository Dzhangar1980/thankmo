---
name: leaflet.TrackPlayBack
category: time-elevation
repo: https://github.com/linghuam/Leaflet.TrackPlayBack
author: linghuam
author-url: https://github.com/linghuam
demo: https://linghuam.github.io/Leaflet.TrackPlayBack/
compatible-v0:
compatible-v1: true
---

A leaflet track-playback plugin, can display and dynamically play tracks.
