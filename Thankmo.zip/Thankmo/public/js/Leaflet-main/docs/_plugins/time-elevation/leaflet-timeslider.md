---
name: Leaflet Time-Slider
category: time-elevation
repo: https://github.com/dwilhelm89/LeafletSlider
author: Dennis Wilhelm
author-url: https://github.com/dwilhelm89
demo: https://dwilhelm89.github.io/LeafletSlider/
compatible-v0:
compatible-v1: true
---

The Leaflet Time-Slider enables you to dynamically add and remove Markers on a map by using a JQuery UI slider
