---
name: Leaflet.GridCluster
category: clustering-decluttering
repo: https://github.com/andy-kay/Leaflet.GridCluster
author: Andreas Kiefer
author-url: https://github.com/andy-kay
demo: http://andy-kay.github.io/Leaflet.GridCluster/
compatible-v0:
compatible-v1: true
---

Create grid-based clusters in realtime.
