---
name: Leaflet.ConditionalLayer
category: clustering-decluttering
repo: https://github.com/Eclipse1979/leaflet-conditionalLayer
author: EPP
author-url: https://github.com/Eclipse1979
demo: http://eclipse1979.github.io/Leaflet.ConditionalLayer/example/leaflet-conditionalLayer2.html
compatible-v0:
compatible-v1: true
---

A FeatureGroup that does not show any more than a certain amount of markers visible in the viewport.
