---
name: Leaflet Categorized Layers
category: layer-switching-controls
repo: https://github.com/robbiet480/leaflet-categorized-layers
author: Robbie Trencheny
author-url: https://robbies.domains
demo: 
compatible-v0:
compatible-v1: true
---

Leaflet Control Layers extended for groups of categorized layers
