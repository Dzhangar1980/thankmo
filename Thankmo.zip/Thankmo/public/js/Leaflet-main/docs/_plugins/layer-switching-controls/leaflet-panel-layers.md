---
name: Leaflet Panel Layers
category: layer-switching-controls
repo: https://github.com/stefanocudini/leaflet-panel-layers
author: Stefano Cudini
author-url: https://opengeo.tech/
demo: 
compatible-v0:
compatible-v1: true
---

Leaflet Control Layers extended for group of layers and icons legend
