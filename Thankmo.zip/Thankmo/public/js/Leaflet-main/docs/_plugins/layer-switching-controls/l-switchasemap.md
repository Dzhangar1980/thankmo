---
name: L.switchBasemap
category: layer-switching-controls
repo: https://github.com/clavijojuan/L.switchBasemap
author: clavijojuan
author-url: https://github.com/clavijojuan
demo: https://elegant-meninsky-515912.netlify.app/
compatible-v0: false
compatible-v1: true
---

An easy leaflet plugin to switch basemap.
