---
name: Leaflet.LayerTreeControl
category: layer-switching-controls
repo: https://github.com/ignaciofagian/L.LayerTreeControl
author: Ignacio Fagian
author-url: https://ignaciofagian.github.io
demo: https://ignaciofagian.github.io/L.LayerTreeControl/example
compatible-v0: false
compatible-v1: true
---

A leaflet plugin to group multiple types of layers in a tree structure.
