---
name: Leaflet.layerscontrol-minimap
category: minimaps-synced-maps
repo: https://github.com/jieter/Leaflet.layerscontrol-minimap
author: Jieter
author-url: https://github.com/jieter
demo: 
compatible-v0:
compatible-v1: true
---

Extends the default Leaflet layers control with synced minimaps.
