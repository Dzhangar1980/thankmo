---
name: Leaflet.SmoothPolygons
category: heatmaps
repo: https://github.com/sanchezweezer/Leaflet.SmoothPolygons
author: Sanchez Weezer
author-url: https://github.com/sanchezweezer
demo: https://sanchezweezer.github.io/Leaflet.SmoothPolygons/docs/
compatible-v0:
compatible-v1: true
---

Uses [paperJS](http://paperjs.org/) under the hood to draw paths on canvas.
