---
name: HeatCanvas
category: heatmaps
repo: https://github.com/sunng87/heatcanvas
author: Sun Ning
author-url: https://github.com/sunng87
demo: https://sunng87.github.io/heatcanvas/leaflet.html
compatible-v0:
compatible-v1: true
---

Simple heatmap api based on HTML canvas.
