---
name: MaskCanvas
category: heatmaps
repo: https://github.com/domoritz/leaflet-maskcanvas
author: Dominik Moritz
author-url: https://github.com/domoritz
demo: https://domoritz.github.io/vbb-coverage/
compatible-v0:
compatible-v1: true
---

Canvas layer that can be used to visualize coverage.
