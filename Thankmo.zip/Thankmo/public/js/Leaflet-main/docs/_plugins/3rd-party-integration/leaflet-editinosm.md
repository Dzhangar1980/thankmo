---
name: Leaflet.EditInOSM
category: 3rd-party-integration
repo: https://github.com/yohanboniface/Leaflet.EditInOSM
author: Yohan Boniface
author-url: https://yohanboniface.me/
demo: http://yohanboniface.github.io/Leaflet.EditInOSM/examples/basic.html
compatible-v0:
compatible-v1: true
---

Add a control with links to open the current map view on main OSM editors.
