---
name: Open User Map
category: 3rd-party-integration
repo: https://wordpress.org/plugins/open-user-map/
author: 100plugins
author-url: https://www.open-user-map.com/?ref=leafletjs.com
demo: https://www.open-user-map.com/demo/
compatible-v0:
compatible-v1: true
---

WordPress plugin to let your visitors add locations directly from the frontend - without registration. They drop a marker on the map and provide some location details. After submit the location proposal will be “pending” and wait for your review approval to get published.
