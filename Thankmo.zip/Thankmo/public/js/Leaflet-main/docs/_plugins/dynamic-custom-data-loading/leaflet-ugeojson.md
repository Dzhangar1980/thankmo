---
name: Leaflet uGeoJSON
category: dynamic-custom-data-loading
repo: https://github.com/BenjaminVadant/leaflet-ugeojson
author: Benjamin VADANT
author-url: https://github.com/BenjaminVadant/
demo: 
compatible-v0:
compatible-v1: true
---

Add an auto updating GeoJSON data Layer via ajax post requests.
