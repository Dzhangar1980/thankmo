---
name: Leaflet.Indoor
category: dynamic-custom-data-loading
repo: https://github.com/cbaines/leaflet-indoor
author: Christopher Baines
author-url: https://github.com/cbaines
demo: https://www.cbaines.net/projects/osm/leaflet-indoor/examples/
compatible-v0:
compatible-v1: true
---

Create indoor maps.
