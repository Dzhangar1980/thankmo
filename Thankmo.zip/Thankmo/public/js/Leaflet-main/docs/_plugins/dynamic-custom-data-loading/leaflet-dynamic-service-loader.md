---
name: Leaflet.DynamicServiceLoader
category: dynamic-custom-data-loading
repo: https://github.com/o-z-e-r-e-r/Leaflet.DynamicServiceLoader
author: Erdem Ozer
author-url: https://github.com/o-z-e-r-e-r
demo: https://o-z-e-r-e-r.github.io/Leaflet.DynamicServiceLoader/
compatible-v0:
compatible-v1: true
---

Dynamically add and manage WMS and WMTS directly from the client side.
