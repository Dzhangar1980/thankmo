---
name: Leaflet TripGo routing
category: routing
repo: https://github.com/skedgo/tripkit-leaflet
author: SkedGo
author-url: https://skedgo.com/
demo: https://skedgo.github.io/tripkit-leaflet/
compatible-v0:
compatible-v1: true
---

The <b>TripGo</b> mobility platform lets you create apps providing seamless and personalised door-to-door trips using any public, private or commercial mode of transport.    		TripGo Leaflet's plugin motivation is to provide an easy way to include its functionality in an external platform.
