---
name: SuperMap Leaflet
category: basemap-providers
repo: https://supermap.github.io/supermap-leaflet/
author: SuperMap
author-url: https://github.com/SuperMap
demo: https://supermap.github.io/supermap-leaflet/example/tiledMapLayer.html
compatible-v0:
compatible-v1: true
---

SuperMap Leaflet is a Leaflet plugins for working with SuperMap service types.         Support for SuperMap services, tiles and more.
