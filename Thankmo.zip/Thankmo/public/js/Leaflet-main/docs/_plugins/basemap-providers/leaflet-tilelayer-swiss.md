---
name: Leaflet.TileLayer.Swiss
category: basemap-providers
repo: https://github.com/rkaravia/Leaflet.TileLayer.Swiss
author: Roman Karavia
author-url: https://github.com/rkaravia
demo: https://leaflet-tilelayer-swiss.karavia.ch/
compatible-v0:
compatible-v1: true
---

Displays national maps of Switzerland using map tiles from Swisstopo.
