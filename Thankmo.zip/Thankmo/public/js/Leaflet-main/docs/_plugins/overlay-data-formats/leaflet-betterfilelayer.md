---
name: Leaflet.BetterFileLayer
category: overlay-data-formats
repo: https://github.com/gabriel-russo/Leaflet.BetterFileLayer
author: Gabriel Russo
author-url: https://github.com/gabriel-russo/
demo: https://gabriel-russo.github.io/Leaflet.BetterFileLayer/example/
compatible-v0: false
compatible-v1: true
---

The definitive plugin to load your spatialized files into leaflet.
