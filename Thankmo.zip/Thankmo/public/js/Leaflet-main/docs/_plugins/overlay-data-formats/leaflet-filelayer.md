---
name: Leaflet.FileLayer
category: overlay-data-formats
repo: https://github.com/makinacorpus/Leaflet.FileLayer
author: Mathieu Leplatre
author-url: https://github.com/leplatrem
demo: 
compatible-v0:
compatible-v1: true
---

Loads files (GeoJSON, GPX, KML) into the map using the HTML FileReader API (i.e. locally without server).
