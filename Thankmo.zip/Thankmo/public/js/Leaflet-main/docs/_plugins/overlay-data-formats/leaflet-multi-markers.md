---
name: Leaflet.MultiMarkers
category: overlay-data-formats
repo: https://github.com/mfhsieh/leaflet-multi-markers
author: mfhsieh
author-url: https://github.com/mfhsieh/
demo: https://mfhsieh.github.io/leaflet-multi-markers/
compatible-v0: 
compatible-v1: true
---

A Leaflet plugin for displaying a large number of highly customizable markers, such as those from a CSV file read using <a href="https://www.papaparse.com/">Papa Parse</a>.
