---
name: leaflet-kml
category: overlay-data-formats
repo: https://github.com/windycom/leaflet-kml
author: Windyx
author-url: https://github.com/windycom
demo: https://www.windy.com/uploader
compatible-v0:
compatible-v1: true
---

Loads &amp; displays KML
