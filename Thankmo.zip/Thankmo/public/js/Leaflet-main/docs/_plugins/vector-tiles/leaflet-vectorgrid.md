---
name: Leaflet.VectorGrid
category: vector-tiles
repo: https://github.com/Leaflet/Leaflet.VectorGrid
author: Iván Sánchez
author-url: https://github.com/IvanSanchez
demo: https://github.com/Leaflet/Leaflet.VectorGrid#demos
compatible-v0: false
compatible-v1: true
---

Display gridded vector data (GeoJSON or TopoJSON sliced with geojson-vt, or protobuf vector tiles) in Leaflet 1.0.0.
