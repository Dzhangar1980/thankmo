---
name: geojson-vt
category: vector-tiles
repo: https://github.com/mapbox/geojson-vt
author: Mapbox
author-url: https://www.mapbox.com/
demo: 
compatible-v0:
compatible-v1: true
---

Efficient library for slicing GeoJSON data into vector tiles on the fly.
