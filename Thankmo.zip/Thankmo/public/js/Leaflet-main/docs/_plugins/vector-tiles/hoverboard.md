---
name: Hoverboard
category: vector-tiles
repo: https://github.com/summer4096/hoverboard
author: Tristan Davies
author-url: https://madd.tech/
demo: https://madd.tech/hoverboard/
compatible-v0: true
compatible-v1: false
---

Render vector tiles on canvas with leaflet (geojson, topojson, and protobuf). Compatible with Leaflet 0.7.x only.
