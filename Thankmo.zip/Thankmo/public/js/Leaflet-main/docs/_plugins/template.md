---
name: required
category: required (same name as directory)
repo: required
author: required
author-url:
demo: 
compatible-v0:
compatible-v1: true
---

Describe here your **plugin**, you can use *markdown* to format your text. Keep it short and check out the [plugin guide](https://github.com/Leaflet/Leaflet/blob/main/PLUGIN-GUIDE.md).
