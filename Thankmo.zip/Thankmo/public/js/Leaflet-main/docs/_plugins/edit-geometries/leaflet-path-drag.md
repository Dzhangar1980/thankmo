---
name: Leaflet.Path.Drag
category: edit-geometries
repo: https://github.com/w8r/Leaflet.Path.Drag
author: Alexander Milevski
author-url: https://github.com/w8r/
demo: https://milevski.co/Leaflet.Path.Drag
compatible-v0:
compatible-v1: true
---

Drag handler and interaction for polygons and polylines.
