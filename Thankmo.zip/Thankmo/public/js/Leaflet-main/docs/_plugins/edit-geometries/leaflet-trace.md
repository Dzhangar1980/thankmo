---
name: Leaflet.trace
category: edit-geometries
repo: https://github.com/agilvarry/Leaflet.trace
author: Alex Gilvarry
author-url: https://github.com/agilvarry
demo: https://agilvarry.github.io/Leaflet.trace/
compatible-v0:
compatible-v1: true
---

Extends Leaflet.draw to add a new set of tools which allow the user to select a L.geoJSON line to trace or snap a marker to. 
