---
name: Leaflet.NACCoordinates
category: mouse-coordinates
repo: https://github.com/mahmoodvcs/Leaflet.NACCoordinates
author: Mahmood Dehghan
author-url: https://github.com/mahmoodvcs
demo:
compatible-v0:
compatible-v1: true
---

Displays NAC coordinate of the mouse pointer on mouse move.
