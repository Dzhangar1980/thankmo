---
name: Leaflet Coordinates Control
category: mouse-coordinates
repo: https://github.com/zimmicz/Leaflet-Coordinates-Control
author: Michal Zimmermann
author-url: https://github.com/zimmicz
demo: https://www.zimmi.cz/Leaflet-Coordinates-Control/
compatible-v0:
compatible-v1: true
---

Captures mouseclick and displays its coordinates with easy way to copy them.
