---
name: Leaflet.MousePosition.ts
category: mouse-coordinates
repo: https://github.com/YUUKIToriyama/Leaflet.MousePosition.ts
author: Yuuki Toriyama
author-url: https://github.com/YUUKIToriyama
demo: https://yuukitoriyama.github.io/Leaflet.MousePosition.ts/
compatible-v0:
compatible-v1: true
---

A fully custmizable coordinate viewer written in TypeScript. You can change how this plugin looks by creating a custom component with JSX.
