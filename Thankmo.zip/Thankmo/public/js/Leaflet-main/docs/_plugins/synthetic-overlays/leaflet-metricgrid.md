---
name: Leaflet.MetricGrid
category: synthetic-overlays
repo: https://github.com/bill-chadwick/Leaflet.MetricGrid
author: Bill Chadwick
author-url: https://github.com/bill-chadwick
demo: 
compatible-v0:
compatible-v1: true
---

A general purpose Metric Grid overlay for Leaflet with ready defined UTM, British and Irish Grids.
