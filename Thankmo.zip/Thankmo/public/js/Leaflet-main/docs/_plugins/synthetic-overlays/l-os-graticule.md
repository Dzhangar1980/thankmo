---
name: L.OS.Graticule
category: synthetic-overlays
repo: https://github.com/jonshutt/Leaflet.OS.Graticule
author: Jon Shutt
author-url: https://github.com/jonshutt
demo: 
compatible-v0:
compatible-v1: true
---

Overlays UK Ordinance Survey (OS) 1km grid squares and labels.
