---
name: leaflet.migration
category: dataviz
repo: https://github.com/lin-123/leaflet.migration
author: Kakaka Hou
author-url: https://github.com/lin-123
demo: https://lin-123.github.io/leaflet.migration/demo
compatible-v0: false
compatible-v1: true
---

This plugin add layer to leaflet which show migration， flylines. User can customize marker, line, popover ext.