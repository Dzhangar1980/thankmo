---
name: Mapstats
category: dataviz
repo: https://www.jklir.net/mapstats.html
author: Jirka Klír
author-url: https://github.com/jklir
demo: https://www.jklir.net/sites/mapstats/index.html
compatible-v0:
compatible-v1: true
---

A Leaflet plugin for display and monitoring (wireless) network on the map.
