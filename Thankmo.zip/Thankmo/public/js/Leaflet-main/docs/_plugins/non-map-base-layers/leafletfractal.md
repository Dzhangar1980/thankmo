---
name: leaflet-fractal
category: non-map-base-layers
repo: https://github.com/aparshin/leaflet-fractal
author: Alexander Parshin
author-url: https://github.com/aparshin
demo: http://aparshin.github.io/leaflet-fractal/
compatible-v0:
compatible-v1: true
---

Renders some fractals (Mandelbrot set, Julia set and some others) using 2D canvas
