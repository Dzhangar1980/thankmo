---
name: Esri Leaflet Geocoder
category: geocoding
repo: https://github.com/Esri/esri-leaflet-geocoder
author: Patrick Arlt
author-url: https://github.com/patrickarlt/
demo: https://esri.github.io/esri-leaflet/examples/
compatible-v0:
compatible-v1: true
---

A geocoding control with suggestions powered by the ArcGIS Online geocoder.
