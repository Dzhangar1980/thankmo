---
name: Leaflet Control OSM Geocoder
category: geocoding
repo: https://github.com/k4r573n/leaflet-control-osm-geocoder
author: Karsten Hinz
author-url: https://github.com/k4r573n
demo: https://k4r573n.github.io/leaflet-control-osm-geocoder/
compatible-v0:
compatible-v1: true
---

A simple geocoder that uses OpenstreetMap Nominatim to locate places by address.
