---
name: Leaflet.Boating
category: geolocation
repo: https://github.com/cdupre/leaflet.boating
author: Clément Dupré
author-url: https://github.com/cdupre
demo: https://cdupre.github.io/leaflet.boating/
compatible-v0:
compatible-v1: true
---

Leaflet plugin to geolocate the user and display heading, speed and location like a simple navigation app.
