---
name: Leaflet.SimpleLocate
category: geolocation
repo: https://github.com/mfhsieh/leaflet-simple-locate/
author: mfhsieh
author-url: https://github.com/mfhsieh
demo: https://mfhsieh.github.io/leaflet-simple-locate/
compatible-v0:
compatible-v1: true
---

A Leaflet plugin displaying device location and orientation on the map, with orientation adjusted according to screen rotation.
