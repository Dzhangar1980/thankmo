---
name: Leaflet.AccuratePosition
category: geolocation
repo: https://github.com/M165437/Leaflet.AccuratePosition
author: Michael Schmidt-Voigt
author-url: https://github.com/M165437
demo: https://m165437.github.io/Leaflet.AccuratePosition/
compatible-v0: true
compatible-v1: false
---

Leaflet.AccuratePosition aims to provide a desired device location accuracy.
