---
name: Leaflet.BorderPan
category: interactive-pan-zoom
repo: https://github.com/slara/Leaflet.BorderPan
author: Sebastián Lara
author-url: https://github.com/slara
demo: 
compatible-v0:
compatible-v1: true
---

A Leaflet plugin to pan by clicking on map borders.
