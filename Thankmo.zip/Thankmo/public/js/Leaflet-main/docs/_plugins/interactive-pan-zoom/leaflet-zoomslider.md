---
name: Leaflet.zoomslider
category: interactive-pan-zoom
repo: https://github.com/kartena/Leaflet.zoomslider/
author: Kartena
author-url: http://www.kartena.se/index.html
demo: https://kartena.github.io/Leaflet.zoomslider/
compatible-v0:
compatible-v1: true
---

A zoom slider control.
