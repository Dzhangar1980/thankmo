---
name: Leaflet.ZoomEx
category: interactive-pan-zoom
repo: https://github.com/mfhsieh/leaflet-zoomex/
author: mfhsieh
author-url: https://github.com/mfhsieh
demo: https://mfhsieh.github.io/leaflet-zoomex/
compatible-v0:
compatible-v1: true
---

A Leaflet plugin that displays a zoom control on the map, with a customizable appearance and position using CSS.