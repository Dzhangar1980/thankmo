---
name: Leaflet.DoubleTouchDragZoom
category: interactive-pan-zoom
repo: https://github.com/petoc/Leaflet.DoubleTouchDragZoom
author: Peter C
author-url: https://github.com/petoc
demo: https://petoc.github.io/Leaflet.DoubleTouchDragZoom/example/
compatible-v0:
compatible-v1: true
---

Plugin for one finger zoom.
