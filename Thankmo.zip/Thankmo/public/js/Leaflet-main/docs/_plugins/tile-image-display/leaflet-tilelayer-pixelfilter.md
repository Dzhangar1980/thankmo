---
name: Leaflet.TileLayer.PixelFilter
category: tile-image-display
repo: https://github.com/GreenInfo-Network/L.TileLayer.PixelFilter/
author: GreenInfo Network
author-url: https://github.com/GreenInfo-Network/
demo: http://greeninfo-network.github.io/L.TileLayer.PixelFilter/demo1.html
compatible-v0:
compatible-v1: true
---

A TileLayer which can filter and replace pixels by RGB code.
