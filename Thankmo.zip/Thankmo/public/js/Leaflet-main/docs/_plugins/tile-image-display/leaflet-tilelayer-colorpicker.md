---
name: Leaflet.TileLayer.ColorPicker
category: tile-image-display
repo: https://github.com/frogcat/leaflet-tilelayer-colorpicker
author: Yuzo Matsuzawa
author-url: https://github.com/frogcat
demo: https://frogcat.github.io/leaflet-tilelayer-colorpicker/
compatible-v0:
compatible-v1: true
---

A Leaflet TileLayer with getColor(latLng).
