---
name: leaflet-custom-headers
category: tile-image-display
repo: https://github.com/fifogipo/leaflet-custom-headers
author: fifogipo
author-url: https://github.com/fifogipo
demo: 
compatible-v0:
compatible-v1: true
---

Leaflet Custom Headers is an extension to `L.TileLayer` that allows you to add **custom headers** to HTTP requests when loading tiles.
