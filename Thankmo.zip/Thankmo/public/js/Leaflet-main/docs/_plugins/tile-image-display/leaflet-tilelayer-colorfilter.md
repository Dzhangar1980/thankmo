---
name: Leaflet.TileLayer.ColorFilter
category: tile-image-display
repo: https://github.com/xtk93x/Leaflet.TileLayer.ColorFilter
author: Cláudio Kawakani
author-url: https://github.com/xtk93x
demo: https://xtk93x.github.io/Leaflet.TileLayer.ColorFilter/
compatible-v0:
compatible-v1: true
---

A simple and lightweight Leaflet plugin to apply CSS filters on map tiles.
