---
name: Leaflet.TileLayer.GLOperations
category: tile-image-display
repo: https://github.com/equinor/leaflet.tilelayer.gloperations
author: Thorbjørn Horgen
author-url: https://github.com/thor85
demo: https://equinor.github.io/leaflet.tilelayer.gloperations/
compatible-v0:
compatible-v1: true
---

WebGL TileLayer: Colorize floating-point pixels, mouse event handlers for pixel values, hillshading, contours, transitions, filter and do calculations on multiple layers.
