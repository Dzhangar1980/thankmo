---
name: Leaflet.Control.Opacity
category: tile-image-display
repo: https://github.com/dayjournal/Leaflet.Control.Opacity
author: Yasunori Kirimoto
author-url: https://day-journal.com/
demo: https://dayjournal.github.io/Leaflet.Control.Opacity/
compatible-v0:
compatible-v1: true
---

Make multiple tile layers transparent.
