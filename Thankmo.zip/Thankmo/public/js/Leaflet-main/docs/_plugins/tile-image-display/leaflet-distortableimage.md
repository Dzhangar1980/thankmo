---
name: Leaflet.DistortableImage
category: tile-image-display
repo: https://github.com/publiclab/Leaflet.DistortableImage
author: Public Lab
author-url: https://github.com/publiclab
demo: https://publiclab.github.io/Leaflet.DistortableImage/examples/index.html
compatible-v0:
compatible-v1: true
---

Enable users to <a href="https://publiclab.github.io/Leaflet.DistortableImage/examples/">scale, rotate, and distort images</a> on Leaflet maps.
