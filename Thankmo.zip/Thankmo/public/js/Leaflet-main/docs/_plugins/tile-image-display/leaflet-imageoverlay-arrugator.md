---
name: Leaflet.ImageOverlay.Arrugator
category: tile-image-display
repo: https://gitlab.com/IvanSanchez/Leaflet.ImageOverlay.Arrugator
author: Iván Sánchez Ortega
author-url: https://ivan.sanchezortega.es/
demo: https://ivansanchez.gitlab.io/Leaflet.ImageOverlay.Arrugator/demo.html
compatible-v0:
compatible-v1: true
---

Displays reprojected ImageOverlays, given four control points and a proj4js projection function.
