---
name: leaflet-rotate
category: tile-image-display
repo: https://github.com/Raruto/leaflet-rotate
author: Raruto
author-url: https://raruto.github.io
demo: https://raruto.github.io/leaflet-rotate/examples/leaflet-rotate.html
compatible-v0: false
compatible-v1: true
---

Adds rotation functionality to leaflet map panes
