---
name: Leaflet.TileLayer.Colorizr
category: tile-image-display
repo: https://github.com/hnrchrdl/leaflet-tilelayer-colorizr
author: Hinrich Riedel
author-url: https://github.com/hnrchrdl
demo: 
compatible-v0:
compatible-v1: true
---

A Leaflet TileLayer which can modify colors by RGBA code.
