---
name: Leaflet.Control.SideBySide
category: tile-image-display
repo: https://github.com/digidem/leaflet-side-by-side
author: Digital Democracy
author-url: https://www.digital-democracy.org/
demo: http://lab.digital-democracy.org/leaflet-side-by-side/
compatible-v0:
compatible-v1: true
---

A Leaflet control to add a split screen to compare two map overlays.
