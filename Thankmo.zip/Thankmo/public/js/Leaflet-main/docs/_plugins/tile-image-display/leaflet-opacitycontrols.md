---
name: Leaflet.OpacityControls
category: tile-image-display
repo: https://github.com/lizardtechblog/Leaflet.OpacityControls
author: Jared Dominguez
author-url: https://github.com/lizardtechblog/
demo: https://lizardtechblog.github.io/Leaflet.OpacityControls/
compatible-v0:
compatible-v1: true
---

Simple Leaflet controls to adjust the opacity of a map layer.
