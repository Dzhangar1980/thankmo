---
name: Leaflet.Viewpoint
category: markers-renderers
repo: https://github.com/ggolikov/Leaflet.Viewpoint
author: Grigory Golikov
author-url: https://github.com/ggolikov
demo: https://ggolikov.github.io/Leaflet.Viewpoint/example/
compatible-v0:
compatible-v1: true
---

Displays circleMarker with multiple directions.	Useful to show photos taken from one point.
