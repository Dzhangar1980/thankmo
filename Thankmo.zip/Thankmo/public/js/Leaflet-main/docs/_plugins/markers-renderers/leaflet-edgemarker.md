---
name: Leaflet.EdgeMarker
category: markers-renderers
repo: https://github.com/ubergesundheit/Leaflet.EdgeMarker
author: Gerald Pape
author-url: https://github.com/ubergesundheit
demo: http://ubergesundheit.github.io/Leaflet.EdgeMarker/
compatible-v0:
compatible-v1: true
---

Plugin to indicate the existence of Features outside of the current view.
