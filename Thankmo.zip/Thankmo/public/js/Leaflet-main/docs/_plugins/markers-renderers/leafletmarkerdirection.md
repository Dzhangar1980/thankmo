---
name: leaflet-marker-direction
category: markers-renderers
repo: https://github.com/Thomas2077/leaflet-marker-direction
author: Thomas Zou
author-url: https://github.com/Thomas2077
demo: https://thomas2077.github.io/leaflet-marker-direction/examples/marker-direction.html
compatible-v0:
compatible-v1: true
---

display the path and the direction of the marker.
