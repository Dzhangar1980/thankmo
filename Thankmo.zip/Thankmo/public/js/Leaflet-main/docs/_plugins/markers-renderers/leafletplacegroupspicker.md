---
name: leaflet-place-groups-picker
category: markers-renderers
repo: https://github.com/damianc/leaflet-place-groups-picker
author: damianc
author-url: https://github.com/damianc
demo: 
compatible-v0:
compatible-v1: true
---

Plugin for the Leaflet maps that allows grouping places in groups whose visibility can be toggled.
