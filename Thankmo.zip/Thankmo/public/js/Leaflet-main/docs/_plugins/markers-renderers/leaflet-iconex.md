---
name: Leaflet.IconEx
category: markers-renderers
repo: https://github.com/mfhsieh/leaflet-iconex/
author: mfhsieh
author-url: https://github.com/mfhsieh
demo: https://mfhsieh.github.io/leaflet-iconex/
compatible-v0:
compatible-v1: true
---

A Leaflet plugin that creates a DivIcon with three customizable layers.