---
name: Leaflet.bezier
category: markers-renderers
repo: https://github.com/lifeeka/leaflet.bezier
author: Supun Praneeth
author-url: https://github.com/spmsupun
demo: https://github.com/lifeeka/leaflet.bezier#demo
compatible-v0:
compatible-v1: true
---

Draws a Bézier line between two points with an animated flight object.
