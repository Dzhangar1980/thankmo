---
name: Leaflet.CustomLayer
category: markers-renderers
repo: https://github.com/iDerekLi/Leaflet.CustomLayer
author: Derek Li
author-url: https://github.com/iDerekLi/
demo: 
compatible-v0:
compatible-v1: true
---

A Leaflet plugin L.CustomLayer - fully custom Layer.
