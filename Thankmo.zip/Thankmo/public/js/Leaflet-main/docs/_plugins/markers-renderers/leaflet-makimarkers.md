---
name: Leaflet.MakiMarkers
category: markers-renderers
repo: https://github.com/jseppi/Leaflet.MakiMarkers
author: James Seppi
author-url: https://github.com/jseppi
demo: 
compatible-v0:
compatible-v1: true
---

Create markers using <a href="https://labs.mapbox.com/maki-icons/">Maki Icons</a> from MapBox.
