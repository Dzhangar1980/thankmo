---
name: leaflet-distance-markers
category: markers-renderers
repo: https://github.com/adoroszlai/leaflet-distance-markers
author: Doroszlai, Attila
author-url: https://github.com/adoroszlai
demo: http://adoroszlai.github.io/leaflet-distance-markers/
compatible-v0:
compatible-v1: true
---

Allows displaying markers along a route (L.Polyline) at equivalent distances (eg. one per mile).
