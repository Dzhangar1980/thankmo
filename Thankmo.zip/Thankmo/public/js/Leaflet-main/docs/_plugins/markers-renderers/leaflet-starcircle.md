---
name: Leaflet.StarCircle
category: markers-renderers
repo: https://github.com/haelue/Leaflet.StarCircle
author: Haelue
author-url: https://github.com/haelue/
demo: https://haelue.github.io/Leaflet.StarCircle/
compatible-v0:
compatible-v1: true
---

Drawing triangle, square, star(n-corner) in leaflet.
