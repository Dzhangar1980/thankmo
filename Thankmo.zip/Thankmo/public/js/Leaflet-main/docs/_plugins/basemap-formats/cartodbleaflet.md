---
name: cartodb-leaflet
category: basemap-formats
repo: https://github.com/vizzuality/cartodb-leaflet/
author: Vizzuality
author-url: https://www.vizzuality.com/
demo: 
compatible-v0:
compatible-v1: true
---

Official <a href="https://carto.com/">CartoDB</a> plugin for Leaflet.
