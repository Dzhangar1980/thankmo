---
name: Leaflet.print
category: print-export
repo: https://github.com/aratcliffe/Leaflet.print
author: Adam Ratcliffe
author-url: https://github.com/aratcliffe
demo: 
compatible-v0:
compatible-v1: true
---

Implements the Mapfish print protocol allowing a Leaflet map to be printed using either the Mapfish or GeoServer print module.
