---
name: leaflet-popup-modifier
category: search-popups
repo: https://github.com/slutske22/leaflet-popup-modifier
author: Slutske22
author-url: https://github.com/slutske22
demo: 
compatible-v0:
compatible-v1: true
---

Allows user to edit the contents of a popup, or use the popup to remove its source marker.
