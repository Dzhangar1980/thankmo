---
name: Leaflet Search
category: search-popups
repo: https://github.com/stefanocudini/leaflet-search
author: Stefano Cudini
author-url: https://opengeo.tech/
demo: https://opengeo.tech/maps/leaflet-search/examples/simple.html
compatible-v0:
compatible-v1: true
---

A control for search Markers/Features location by custom property in LayerGroup/GeoJSON. Support AJAX/JSONP, Autocompletion and 3rd party service
