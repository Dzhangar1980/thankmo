---
name: Leaflet.PopupMovable
category: search-popups
repo: https://github.com/wrwrh/leaflet-popupmovable
author: Yasuhiro Suzuki
author-url: https://github.com/wrwrh/
demo: https://wrwrh.github.io/leaflet-popupmovable/Demo/index.html
compatible-v0: false
compatible-v1: true
---

This plug-in makes L.Popup movable by user drag and automatically draws leads.
