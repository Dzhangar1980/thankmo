---
name: L.tagFilterButton
category: search-popups
repo: https://github.com/maydemirx/leaflet-tag-filter-button
author: Mehmet Aydemir
author-url: https://github.com/maydemirx
demo: https://maydemirx.github.io/leaflet-tag-filter-button/
compatible-v0:
compatible-v1: true
---

LeafLet marker filtering by tags
