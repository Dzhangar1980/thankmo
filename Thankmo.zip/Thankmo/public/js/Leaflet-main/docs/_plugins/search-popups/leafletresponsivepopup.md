---
name: leaflet-responsive-popup
category: search-popups
repo: https://github.com/yafred/leaflet-responsive-popup
author: YaFred
author-url: https://github.com/yafred
demo: https://yafred.github.io/leaflet-responsive-popup/default-marker-tip
compatible-v0:
compatible-v1: true
---

Removes the need to move the map to be able to see the content of the popup.
